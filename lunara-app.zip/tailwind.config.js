/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        lunara: {
          purple: '#8B6F9B',
          pink: '#D4A5A5',
          cream: '#FDF8F5',
          gold: '#E8B86D',
          dark: '#3D3D3D',
          light: '#F5F0ED',
          rose: '#C9A9A6',
        }
      }
    },
  },
  plugins: [],
}
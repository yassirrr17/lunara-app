"use client"

import { useState, useEffect } from "react"
import {
  Home,
  Activity,
  MessageCircle,
  BookOpen,
  Users,
  User,
  Crown,
  ChevronRight,
  Check,
  X,
  Moon,
  LogOut,
  Sparkles,
} from "lucide-react"
import Dashboard from "@/components/Dashboard"
import SymptomTracker from "@/components/SymptomTracker"
import LunaChat from "@/components/LunaChat"
import EducationHub from "@/components/EducationHub"
import Community from "@/components/Community"

type Screen = "dashboard" | "symptoms" | "luna" | "learn" | "community" | "premium" | "profile"

export default function App() {
  const [screen, setScreen] = useState<Screen>("dashboard")
  const [isPremium, setIsPremium] = useState(false)
  const [userName, setUserName] = useState("")
  const [showOnboarding, setShowOnboarding] = useState(false)
  const [onboardingStep, setOnboardingStep] = useState(0)
  const [tempName, setTempName] = useState("")
  const [tempAge, setTempAge] = useState("")

  useEffect(() => {
    const saved = localStorage.getItem("lunara_user")
    if (!saved) {
      setShowOnboarding(true)
    } else {
      const user = JSON.parse(saved)
      setIsPremium(user.premium || false)
      setUserName(user.name || "")
    }
  }, [])

  const saveUser = (name: string, age: string, premium: boolean = false) => {
    const user = { name, age, premium }
    localStorage.setItem("lunara_user", JSON.stringify(user))
    setUserName(name)
    setIsPremium(premium)
  }

  const completeOnboarding = () => {
    if (tempName.trim()) {
      saveUser(tempName, tempAge)
      setShowOnboarding(false)
    }
  }

  const togglePremium = () => {
    const saved = localStorage.getItem("lunara_user")
    if (saved) {
      const user = JSON.parse(saved)
      user.premium = !user.premium
      localStorage.setItem("lunara_user", JSON.stringify(user))
      setIsPremium(user.premium)
    }
  }

  const logout = () => {
    localStorage.removeItem("lunara_user")
    localStorage.removeItem("lunara_symptoms")
    window.location.reload()
  }

  const navItems = [
    { id: "dashboard" as Screen, icon: Home, label: "Home" },
    { id: "symptoms" as Screen, icon: Activity, label: "Track" },
    { id: "luna" as Screen, icon: MessageCircle, label: "Luna" },
    { id: "learn" as Screen, icon: BookOpen, label: "Learn" },
    { id: "community" as Screen, icon: Users, label: "Community" },
  ]

  return (
    <div className="min-h-screen bg-lunara-cream">
      {/* Onboarding */}
      {showOnboarding && (
        <div className="fixed inset-0 bg-lunara-cream z-50 flex items-center justify-center p-6">
          <div className="w-full max-w-sm animate-fade-in">
            {onboardingStep === 0 && (
              <div className="text-center">
                <div className="w-20 h-20 bg-lunara-purple/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Moon size={40} className="text-lunara-purple" />
                </div>
                <h1 className="text-3xl font-bold mb-3">Welcome to Lunara</h1>
                <p className="text-gray-500 mb-8">
                  Your personal companion for navigating menopause with confidence, support, and evidence-based guidance.
                </p>
                <button
                  onClick={() => setOnboardingStep(1)}
                  className="w-full py-4 rounded-2xl bg-lunara-purple text-white font-semibold hover:bg-lunara-purple/90 transition-all"
                >
                  Get Started
                </button>
              </div>
            )}

            {onboardingStep === 1 && (
              <div>
                <button
                  onClick={() => setOnboardingStep(0)}
                  className="text-gray-400 mb-6 flex items-center gap-1 text-sm"
                >
                  Back
                </button>
                <h2 className="text-2xl font-bold mb-2">Let us get to know you</h2>
                <p className="text-gray-500 text-sm mb-6">This helps us personalize your experience</p>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium block mb-2">What should we call you?</label>
                    <input
                      type="text"
                      value={tempName}
                      onChange={(e) => setTempName(e.target.value)}
                      placeholder="Your name"
                      className="w-full bg-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-lunara-purple/30"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium block mb-2">Age (optional)</label>
                    <input
                      type="number"
                      value={tempAge}
                      onChange={(e) => setTempAge(e.target.value)}
                      placeholder="45"
                      className="w-full bg-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-lunara-purple/30"
                    />
                  </div>
                </div>

                <button
                  onClick={completeOnboarding}
                  disabled={!tempName.trim()}
                  className="w-full py-4 mt-8 rounded-2xl bg-lunara-purple text-white font-semibold hover:bg-lunara-purple/90 transition-all disabled:opacity-50"
                >
                  Continue
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-md mx-auto px-4 pt-6 pb-24">
        {screen === "dashboard" && <Dashboard onNavigate={setScreen} />}
        {screen === "symptoms" && <SymptomTracker />}
        {screen === "luna" && <LunaChat isPremium={isPremium} />}
        {screen === "learn" && <EducationHub isPremium={isPremium} onNavigate={setScreen} />}
        {screen === "community" && <Community />}

        {screen === "premium" && (
          <div className="space-y-6 pb-24 animate-fade-in">
            <div className="text-center py-6">
              <div className="w-16 h-16 bg-lunara-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Crown size={32} className="text-lunara-gold" />
              </div>
              <h1 className="text-2xl font-bold">Lunara Premium</h1>
              <p className="text-gray-500 text-sm mt-2">Unlock your full wellness potential</p>
            </div>

            {/* Toggle for demo purposes */}
            <div className="glass-card rounded-2xl p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Sparkles size={20} className="text-lunara-gold" />
                  <div>
                    <p className="font-semibold text-sm">Demo Mode</p>
                    <p className="text-xs text-gray-500">Toggle premium status</p>
                  </div>
                </div>
                <button
                  onClick={togglePremium}
                  className={`w-12 h-7 rounded-full transition-all relative ${
                    isPremium ? "bg-lunara-purple" : "bg-gray-300"
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full absolute top-1 transition-all shadow-sm ${
                      isPremium ? "left-6" : "left-1"
                    }`}
                  />
                </button>
              </div>
            </div>

            <div className="grid gap-4">
              <div className="glass-card rounded-2xl p-5 shadow-sm border-2 border-lunara-gold/30">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold">Monthly</h3>
                  <span className="text-2xl font-bold text-lunara-purple">$10<span className="text-sm font-normal text-gray-500">/mo</span></span>
                </div>
                <ul className="space-y-2 mb-4">
                  {["Unlimited Luna AI conversations", "Premium articles & guides", "Weekly health reports", "Personalized meal plans", "Workout programs"].map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm">
                      <Check size={14} className="text-green-500 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={togglePremium}
                  className="w-full py-3 rounded-xl bg-lunara-purple text-white font-medium hover:bg-lunara-purple/90 transition-all"
                >
                  {isPremium ? "Subscribed" : "Choose Monthly"}
                </button>
              </div>

              <div className="glass-card rounded-2xl p-5 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold">Yearly</h3>
                    <span className="text-xs bg-lunara-gold/20 text-lunara-gold px-2 py-0.5 rounded-full font-medium">Save 50%</span>
                  </div>
                  <span className="text-2xl font-bold text-lunara-purple">$60<span className="text-sm font-normal text-gray-500">/yr</span></span>
                </div>
                <ul className="space-y-2 mb-4">
                  {["Everything in Monthly", "Priority support", "Exclusive community events", "Early access to new features"].map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm">
                      <Check size={14} className="text-green-500 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={togglePremium}
                  className="w-full py-3 rounded-xl border-2 border-lunara-purple text-lunara-purple font-medium hover:bg-lunara-purple hover:text-white transition-all"
                >
                  {isPremium ? "Subscribed" : "Choose Yearly"}
                </button>
              </div>
            </div>

            <p className="text-xs text-center text-gray-400">
              In a real app, this would connect to Stripe. For demo, use the toggle above.
            </p>
          </div>
        )}

        {screen === "profile" && (
          <div className="space-y-6 pb-24 animate-fade-in">
            <h1 className="text-2xl font-bold">Profile</h1>

            <div className="glass-card rounded-2xl p-6 shadow-sm text-center">
              <div className="w-20 h-20 bg-lunara-purple/10 rounded-full flex items-center justify-center mx-auto mb-3">
                <User size={32} className="text-lunara-purple" />
              </div>
              <h2 className="font-bold text-lg">{userName || "Guest"}</h2>
              {isPremium && (
                <span className="inline-flex items-center gap-1 text-xs bg-lunara-gold/20 text-lunara-gold px-3 py-1 rounded-full mt-2 font-medium">
                  <Crown size={12} />
                  Premium Member
                </span>
              )}
            </div>

            <div className="glass-card rounded-2xl shadow-sm overflow-hidden">
              <button
                onClick={() => setScreen("premium")}
                className="w-full flex items-center justify-between p-4 hover:bg-lunara-light transition-all text-left"
              >
                <div className="flex items-center gap-3">
                  <Crown size={18} className="text-lunara-gold" />
                  <span className="text-sm font-medium">Subscription</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-400">{isPremium ? "Premium" : "Free"}</span>
                  <ChevronRight size={16} className="text-gray-300" />
                </div>
              </button>
              <div className="h-px bg-gray-100 mx-4" />
              <button
                onClick={() => setShowOnboarding(true)}
                className="w-full flex items-center justify-between p-4 hover:bg-lunara-light transition-all text-left"
              >
                <div className="flex items-center gap-3">
                  <User size={18} className="text-lunara-purple" />
                  <span className="text-sm font-medium">Edit Profile</span>
                </div>
                <ChevronRight size={16} className="text-gray-300" />
              </button>
              <div className="h-px bg-gray-100 mx-4" />
              <button
                onClick={logout}
                className="w-full flex items-center gap-3 p-4 hover:bg-red-50 transition-all text-left text-red-500"
              >
                <LogOut size={18} />
                <span className="text-sm font-medium">Reset App Data</span>
              </button>
            </div>

            <div className="text-center">
              <p className="text-xs text-gray-400">Lunara v0.1.0</p>
              <p className="text-xs text-gray-400 mt-1">Made with care for women in menopause</p>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      {screen !== "premium" && screen !== "profile" && (
        <nav className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-lg border-t border-gray-100">
          <div className="max-w-md mx-auto flex justify-around py-2">
            {navItems.map((item) => {
              const Icon = item.icon
              const isActive = screen === item.id
              return (
                <button
                  key={item.id}
                  onClick={() => setScreen(item.id)}
                  className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all ${
                    isActive ? "text-lunara-purple" : "text-gray-400 hover:text-gray-600"
                  }`}
                >
                  <Icon size={22} strokeWidth={isActive ? 2.5 : 2} />
                  <span className="text-[10px] font-medium">{item.label}</span>
                </button>
              )
            })}
          </div>
        </nav>
      )}

      {/* Top bar for premium/profile screens */}
      {(screen === "premium" || screen === "profile") && (
        <button
          onClick={() => setScreen("dashboard")}
          className="fixed top-4 left-4 z-40 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center shadow-sm"
        >
          <X size={18} />
        </button>
      )}

      {/* Profile button */}
      <button
        onClick={() => setScreen("profile")}
        className="fixed top-4 right-4 z-40 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center shadow-sm hover:shadow-md transition-all"
      >
        <User size={18} className="text-lunara-purple" />
      </button>
    </div>
  )
}
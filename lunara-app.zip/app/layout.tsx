export const metadata = {
  title: 'Lunara - Menopause Wellness',
  description: 'Your companion for menopause wellness',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-lunara-cream text-lunara-dark font-sans antialiased">
        {children}
      </body>
    </html>
  )
}
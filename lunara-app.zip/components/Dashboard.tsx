"use client"

import { useEffect, useState } from "react"
import { Heart, TrendingUp, MessageCircle, BookOpen, Sparkles, ChevronRight } from "lucide-react"

export default function Dashboard({ onNavigate }: { onNavigate: (screen: string) => void }) {
  const [userName, setUserName] = useState("there")
  const [todaySymptoms, setTodaySymptoms] = useState<any[]>([])
  const [isPremium, setIsPremium] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem("lunara_user")
    if (saved) {
      const user = JSON.parse(saved)
      setUserName(user.name || "there")
      setIsPremium(user.premium || false)
    }
    const symptoms = localStorage.getItem("lunara_symptoms")
    if (symptoms) {
      const all = JSON.parse(symptoms)
      const today = new Date().toDateString()
      setTodaySymptoms(all.filter((s: any) => new Date(s.date).toDateString() === today))
    }
  }, [])

  const greeting = () => {
    const hour = new Date().getHours()
    if (hour < 12) return "Good morning"
    if (hour < 17) return "Good afternoon"
    return "Good evening"
  }

  const avgSeverity = todaySymptoms.length
    ? Math.round(todaySymptoms.reduce((a, b) => a + b.severity, 0) / todaySymptoms.length)
    : 0

  return (
    <div className="space-y-6 pb-24 animate-fade-in">
      {/* Header */}
      <div className="bg-gradient-to-br from-lunara-purple to-lunara-pink rounded-3xl p-6 text-white shadow-lg">
        <p className="text-white/80 text-sm">{greeting()}, {userName}</p>
        <h1 className="text-2xl font-bold mt-1">Welcome to Lunara</h1>
        <p className="text-white/80 text-sm mt-2">Your daily companion for menopause wellness</p>
        {!isPremium && (
          <button
            onClick={() => onNavigate("premium")}
            className="mt-4 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-medium flex items-center gap-2 transition-all"
          >
            <Sparkles size={16} />
            Unlock Premium
          </button>
        )}
      </div>

      {/* Today's Snapshot */}
      <div className="glass-card rounded-2xl p-5 shadow-sm">
        <h2 className="font-semibold text-lg mb-4">Today&apos;s Snapshot</h2>
        {todaySymptoms.length > 0 ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Symptoms logged</span>
              <span className="font-semibold">{todaySymptoms.length}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Average severity</span>
              <div className="flex items-center gap-2">
                <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-lunara-purple rounded-full transition-all"
                    style={{ width: `${avgSeverity * 10}%` }}
                  />
                </div>
                <span className="font-semibold text-sm">{avgSeverity}/10</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {todaySymptoms.map((s, i) => (
                <span key={i} className="text-xs bg-lunara-light text-lunara-purple px-3 py-1 rounded-full">
                  {s.name}
                </span>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-4">
            <p className="text-gray-500 text-sm">No symptoms logged today</p>
            <button
              onClick={() => onNavigate("symptoms")}
              className="mt-3 text-lunara-purple text-sm font-medium hover:underline"
            >
              Log your first symptom
            </button>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4">
        <button
          onClick={() => onNavigate("symptoms")}
          className="glass-card rounded-2xl p-5 text-left shadow-sm hover:shadow-md transition-all group"
        >
          <div className="w-10 h-10 bg-lunara-pink/20 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <TrendingUp size={20} className="text-lunara-purple" />
          </div>
          <p className="font-semibold text-sm">Track Symptoms</p>
          <p className="text-xs text-gray-500 mt-1">Log how you feel</p>
        </button>

        <button
          onClick={() => onNavigate("luna")}
          className="glass-card rounded-2xl p-5 text-left shadow-sm hover:shadow-md transition-all group"
        >
          <div className="w-10 h-10 bg-lunara-gold/20 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <MessageCircle size={20} className="text-lunara-gold" />
          </div>
          <p className="font-semibold text-sm">Ask Luna</p>
          <p className="text-xs text-gray-500 mt-1">AI health companion</p>
        </button>

        <button
          onClick={() => onNavigate("learn")}
          className="glass-card rounded-2xl p-5 text-left shadow-sm hover:shadow-md transition-all group"
        >
          <div className="w-10 h-10 bg-lunara-purple/20 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <BookOpen size={20} className="text-lunara-purple" />
          </div>
          <p className="font-semibold text-sm">Learn</p>
          <p className="text-xs text-gray-500 mt-1">Articles & guides</p>
        </button>

        <button
          onClick={() => onNavigate("community")}
          className="glass-card rounded-2xl p-5 text-left shadow-sm hover:shadow-md transition-all group"
        >
          <div className="w-10 h-10 bg-lunara-rose/20 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <Heart size={20} className="text-lunara-rose" />
          </div>
          <p className="font-semibold text-sm">Community</p>
          <p className="text-xs text-gray-500 mt-1">Connect with others</p>
        </button>
      </div>

      {/* Health Tip */}
      <div className="bg-gradient-to-r from-lunara-gold/10 to-lunara-pink/10 rounded-2xl p-5 border border-lunara-gold/20">
        <div className="flex items-start gap-3">
          <Sparkles size={20} className="text-lunara-gold mt-0.5 shrink-0" />
          <div>
            <p className="font-semibold text-sm">Daily Tip</p>
            <p className="text-sm text-gray-600 mt-1">
              Staying hydrated can help reduce hot flashes. Aim for 8 glasses of water today and notice the difference.
            </p>
          </div>
        </div>
      </div>

      {/* Weekly Report Teaser */}
      {!isPremium && (
        <div className="glass-card rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold text-sm">Weekly Health Report</p>
              <p className="text-xs text-gray-500 mt-1">Personalized insights based on your symptoms</p>
            </div>
            <button
              onClick={() => onNavigate("premium")}
              className="text-lunara-purple hover:text-lunara-dark transition-colors"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
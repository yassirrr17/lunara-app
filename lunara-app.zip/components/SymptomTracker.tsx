"use client"

import { useState, useEffect } from "react"
import { Plus, X, Calendar, TrendingUp } from "lucide-react"

const SYMPTOMS = [
  { name: "Hot Flashes", icon: "🔥" },
  { name: "Night Sweats", icon: "💧" },
  { name: "Mood Changes", icon: "🎭" },
  { name: "Sleep Issues", icon: "🌙" },
  { name: "Brain Fog", icon: "🌫️" },
  { name: "Joint Pain", icon: "🦴" },
  { name: "Weight Gain", icon: "⚖️" },
  { name: "Low Libido", icon: "💔" },
  { name: "Anxiety", icon: "😰" },
  { name: "Fatigue", icon: "😴" },
  { name: "Headaches", icon: "🤕" },
  { name: "Dry Skin", icon: "🧴" },
]

export default function SymptomTracker() {
  const [selectedSymptoms, setSelectedSymptoms] = useState<any[]>([])
  const [history, setHistory] = useState<any[]>([])
  const [showAdd, setShowAdd] = useState(false)
  const [selectedToAdd, setSelectedToAdd] = useState<string | null>(null)
  const [severity, setSeverity] = useState(5)
  const [notes, setNotes] = useState("")

  useEffect(() => {
    const saved = localStorage.getItem("lunara_symptoms")
    if (saved) setHistory(JSON.parse(saved))
  }, [])

  const saveSymptoms = (data: any[]) => {
    localStorage.setItem("lunara_symptoms", JSON.stringify(data))
    setHistory(data)
  }

  const addSymptom = () => {
    if (!selectedToAdd) return
    const entry = {
      id: Date.now(),
      name: selectedToAdd,
      severity,
      notes,
      date: new Date().toISOString(),
    }
    const updated = [entry, ...history]
    saveSymptoms(updated)
    setSelectedToAdd(null)
    setSeverity(5)
    setNotes("")
    setShowAdd(false)
  }

  const deleteSymptom = (id: number) => {
    const updated = history.filter((h) => h.id !== id)
    saveSymptoms(updated)
  }

  const todayEntries = history.filter(
    (h) => new Date(h.date).toDateString() === new Date().toDateString()
  )

  const last7Days = history.filter((h) => {
    const d = new Date(h.date)
    const weekAgo = new Date()
    weekAgo.setDate(weekAgo.getDate() - 7)
    return d >= weekAgo
  })

  const symptomCounts: Record<string, number> = {}
  last7Days.forEach((h) => {
    symptomCounts[h.name] = (symptomCounts[h.name] || 0) + 1
  })

  const topSymptoms = Object.entries(symptomCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)

  return (
    <div className="space-y-6 pb-24 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Symptom Tracker</h1>
        <button
          onClick={() => setShowAdd(true)}
          className="bg-lunara-purple text-white p-3 rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all"
        >
          <Plus size={20} />
        </button>
      </div>

      {/* Today's Log */}
      <div className="glass-card rounded-2xl p-5 shadow-sm">
        <h2 className="font-semibold mb-4 flex items-center gap-2">
          <Calendar size={18} className="text-lunara-purple" />
          Today
        </h2>
        {todayEntries.length > 0 ? (
          <div className="space-y-3">
            {todayEntries.map((entry) => (
              <div key={entry.id} className="flex items-center justify-between bg-white/50 rounded-xl p-3">
                <div className="flex-1">
                  <p className="font-medium text-sm">{entry.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="w-20 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{
                          width: `${entry.severity * 10}%`,
                          backgroundColor:
                            entry.severity <= 3
                              ? "#86efac"
                              : entry.severity <= 6
                              ? "#fde047"
                              : "#fca5a5",
                        }}
                      />
                    </div>
                    <span className="text-xs text-gray-500">{entry.severity}/10</span>
                  </div>
                  {entry.notes && <p className="text-xs text-gray-500 mt-1">{entry.notes}</p>}
                </div>
                <button
                  onClick={() => deleteSymptom(entry.id)}
                  className="text-gray-400 hover:text-red-400 p-1"
                >
                  <X size={16} />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 text-sm text-center py-4">No symptoms logged today yet</p>
        )}
      </div>

      {/* Weekly Trends */}
      {topSymptoms.length > 0 && (
        <div className="glass-card rounded-2xl p-5 shadow-sm">
          <h2 className="font-semibold mb-4 flex items-center gap-2">
            <TrendingUp size={18} className="text-lunara-purple" />
            This Week (Top Symptoms)
          </h2>
          <div className="space-y-3">
            {topSymptoms.map(([name, count]) => (
              <div key={name} className="flex items-center justify-between">
                <span className="text-sm">{name}</span>
                <div className="flex items-center gap-3">
                  <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-lunara-pink rounded-full"
                      style={{ width: `${Math.min(count * 15, 100)}%` }}
                    />
                  </div>
                  <span className="text-xs text-gray-500 w-8 text-right">{count}x</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add Symptom Modal */}
      {showAdd && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 animate-fade-in shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-lg">Log Symptom</h3>
              <button onClick={() => setShowAdd(false)} className="text-gray-400 hover:text-gray-600">
                <X size={20} />
              </button>
            </div>

            {!selectedToAdd ? (
              <div className="grid grid-cols-3 gap-3">
                {SYMPTOMS.map((s) => (
                  <button
                    key={s.name}
                    onClick={() => setSelectedToAdd(s.name)}
                    className="bg-lunara-light hover:bg-lunara-purple/10 rounded-xl p-3 text-center transition-all hover:scale-105"
                  >
                    <span className="text-2xl">{s.icon}</span>
                    <p className="text-xs mt-1 font-medium">{s.name}</p>
                  </button>
                ))}
              </div>
            ) : (
              <div className="space-y-5">
                <p className="text-center font-medium text-lunara-purple">{selectedToAdd}</p>

                <div>
                  <label className="text-sm text-gray-600 block mb-2">Severity: {severity}/10</label>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={severity}
                    onChange={(e) => setSeverity(Number(e.target.value))}
                    className="w-full accent-lunara-purple"
                  />
                  <div className="flex justify-between text-xs text-gray-400 mt-1">
                    <span>Mild</span>
                    <span>Severe</span>
                  </div>
                </div>

                <div>
                  <label className="text-sm text-gray-600 block mb-2">Notes (optional)</label>
                  <textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="How did it feel? Any triggers?"
                    className="w-full bg-lunara-light rounded-xl p-3 text-sm resize-none h-20 focus:outline-none focus:ring-2 focus:ring-lunara-purple/30"
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setSelectedToAdd(null)}
                    className="flex-1 py-3 rounded-xl border border-gray-200 text-sm font-medium hover:bg-gray-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    onClick={addSymptom}
                    className="flex-1 py-3 rounded-xl bg-lunara-purple text-white text-sm font-medium hover:bg-lunara-purple/90 transition-all"
                  >
                    Save
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
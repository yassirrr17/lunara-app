"use client"

import { useState, useRef, useEffect } from "react"
import { Send, Sparkles, User, Lock } from "lucide-react"

interface Message {
  id: number
  text: string
  sender: "user" | "luna"
  isPremiumTeaser?: boolean
}

const PREMIUM_TOPICS = [
  "hormone", "hrt", "replacement", "therapy", "bioidentical", "estrogen", "progesterone",
  "testosterone", "prescription", "medication", "drug", "supplement", "vitamin", "dose",
  "dosage", "treatment plan", "daily plan", "meal plan", "workout plan", "full guide",
  "detailed", "comprehensive report", "health report", "weekly report", "personalized",
  "recipe", "recipes", "advanced", "in-depth", "premium", "exclusive"
]

const FREE_RESPONSES: Record<string, string> = {
  "hot flash": "Hot flashes are one of the most common symptoms of menopause. They can feel like a sudden wave of heat spreading through your body. Staying cool, dressing in layers, and avoiding triggers like spicy foods and caffeine can help. Deep breathing exercises when you feel one coming on can also make a difference.",
  "hot flashes": "Hot flashes are one of the most common symptoms of menopause. They can feel like a sudden wave of heat spreading through your body. Staying cool, dressing in layers, and avoiding triggers like spicy foods and caffeine can help. Deep breathing exercises when you feel one coming on can also make a difference.",
  "sleep": "Sleep disturbances during menopause are very common, often caused by night sweats or hormonal changes. Try keeping your bedroom cool, establishing a regular bedtime routine, and avoiding screens an hour before bed. A warm bath with lavender can also signal to your body that it is time to wind down.",
  "night sweat": "Night sweats can really disrupt your rest. Consider moisture-wicking sleepwear and breathable cotton sheets. Keeping a cool glass of water by your bed and a fan nearby can help you get back to sleep faster when they strike.",
  "night sweats": "Night sweats can really disrupt your rest. Consider moisture-wicking sleepwear and breathable cotton sheets. Keeping a cool glass of water by your bed and a fan nearby can help you get back to sleep faster when they strike.",
  "mood": "Mood changes during menopause are completely normal. Hormonal shifts can affect your emotional balance. Regular exercise, even a short walk, can boost endorphins. Talking to friends or journaling your feelings can also provide relief. If low moods persist, speaking with a healthcare provider is a good step.",
  "anxiety": "Feeling more anxious during menopause is common due to hormonal fluctuations. Grounding techniques like the 5-4-3-2-1 method can help in the moment. Regular mindfulness or meditation practice, even just five minutes a day, can build resilience over time.",
  "brain fog": "Brain fog during menopause can feel frustrating. Staying hydrated, getting quality sleep, and keeping your brain active with puzzles or reading can help. Some women find that reducing sugar and eating omega-3 rich foods like salmon supports mental clarity.",
  "weight": "Weight gain during menopause often shifts to the midsection due to metabolic changes. Focus on strength training to maintain muscle mass, which helps burn calories. Protein-rich meals and reducing processed foods can make a real difference. Remember, small consistent changes beat extreme diets.",
  "exercise": "Movement is powerful during menopause. A mix of strength training, walking, and yoga tends to work well. Strength training helps with bone density and metabolism, while yoga supports flexibility and stress relief. Even 20 minutes a day can transform how you feel.",
  "diet": "A balanced diet during menopause emphasizes whole foods, lean proteins, healthy fats, and plenty of vegetables. Calcium and vitamin D are especially important for bone health. Reducing alcohol and caffeine can also help with hot flashes and sleep quality.",
  "nutrition": "A balanced diet during menopause emphasizes whole foods, lean proteins, healthy fats, and plenty of vegetables. Calcium and vitamin D are especially important for bone health. Reducing alcohol and caffeine can also help with hot flashes and sleep quality.",
  "hello": "Hello! I am Luna, your menopause wellness companion. I am here to answer your questions, offer support, and help you navigate this journey with confidence. What is on your mind today?",
  "hi": "Hello! I am Luna, your menopause wellness companion. I am here to answer your questions, offer support, and help you navigate this journey with confidence. What is on your mind today?",
  "help": "I can help you with information about menopause symptoms, lifestyle tips, exercise, nutrition, sleep, and emotional wellbeing. I can also track patterns in your symptoms over time. What would you like to know?",
  "bone": "Bone health becomes especially important during and after menopause due to lower estrogen levels. Weight-bearing exercises like walking and strength training help maintain bone density. Ensure you are getting enough calcium and vitamin D through diet or supplements if needed.",
  "skin": "Many women notice their skin becoming drier during menopause. A good moisturizer with hyaluronic acid, staying hydrated, and protecting your skin from the sun are key. Collagen supplements may also help some women, though results vary.",
  "libido": "Changes in libido during menopause are very common and nothing to be ashamed of. Open communication with your partner, stress reduction, and prioritizing self-care can help. If it is concerning you, a healthcare provider can discuss options including local estrogen treatments.",
  "fatigue": "Persistent fatigue during menopause can stem from poor sleep, hormonal changes, or iron levels. Prioritize sleep hygiene, stay active even when tired (it actually boosts energy), and consider checking your iron and thyroid levels with your doctor.",
  "headache": "Hormonal headaches can increase during perimenopause. Keeping a headache diary to identify triggers helps. Regular meals, hydration, and managing stress are foundational. Some women find relief through magnesium supplements, but check with your doctor first.",
  "headaches": "Hormonal headaches can increase during perimenopause. Keeping a headache diary to identify triggers helps. Regular meals, hydration, and managing stress are foundational. Some women find relief through magnesium supplements, but check with your doctor first.",
  "joint": "Joint pain and stiffness can appear or worsen during menopause. Anti-inflammatory foods like turmeric, ginger, and oily fish may help. Low-impact exercises like swimming and yoga keep joints mobile without adding stress. Omega-3 supplements are also popular for joint support.",
  "stress": "Stress management is crucial during menopause because stress can actually worsen symptoms like hot flashes. Try diaphragmatic breathing, progressive muscle relaxation, or even just five minutes of quiet time daily. You deserve that pause.",
}

const PREMIUM_TEASERS: Record<string, string> = {
  "hormone": "hormone therapy and bioidentical options",
  "hrt": "HRT protocols and personalized hormone balancing",
  "replacement": "hormone replacement strategies",
  "therapy": "specialized menopause treatment protocols",
  "bioidentical": "bioidentical hormone options",
  "estrogen": "estrogen therapy guidance",
  "progesterone": "progesterone balancing techniques",
  "testosterone": "testosterone's role in menopause wellness",
  "prescription": "prescription treatment pathways",
  "medication": "medication management for menopause",
  "drug": "pharmaceutical options and considerations",
  "supplement": "advanced supplement protocols",
  "vitamin": "targeted vitamin regimens",
  "dose": "personalized dosing strategies",
  "dosage": "optimal dosage guidelines",
  "treatment plan": "comprehensive treatment planning",
  "daily plan": "personalized daily wellness plans",
  "meal plan": "nutritionist-designed meal plans",
  "workout plan": "trainer-created workout programs",
  "full guide": "our complete in-depth guides",
  "detailed": "detailed clinical insights",
  "comprehensive report": "your personalized health report",
  "health report": "your weekly health analysis",
  "weekly report": "trend analysis and reports",
  "personalized": "personalized recommendations",
  "recipe": "our curated recipe collection",
  "recipes": "hormone-balancing recipes",
  "advanced": "advanced wellness protocols",
  "in-depth": "in-depth clinical research",
  "premium": "Premium content",
  "exclusive": "exclusive member content",
}

function getLunaResponse(text: string, isPremium: boolean): { text: string; isPremiumTeaser?: boolean } {
  const lower = text.toLowerCase()

  // Check for premium topics first
  if (!isPremium) {
    for (const topic of PREMIUM_TOPICS) {
      if (lower.includes(topic)) {
        const teaser = PREMIUM_TEASERS[topic] || "that topic"
        return {
          text: `I would love to go deeper on this for you. The full guide covering ${teaser} is waiting inside Premium. I can share the basics with you now, but the detailed protocols, personalized plans, and expert insights are part of our Premium library.`,
          isPremiumTeaser: true,
        }
      }
    }
  }

  // Check free responses
  for (const [key, response] of Object.entries(FREE_RESPONSES)) {
    if (lower.includes(key)) {
      return { text: response }
    }
  }

  // Default response
  return {
    text: "That is a great question. I understand this phase of life brings up so many unique concerns. While I can offer general wellness guidance, I would love to understand your situation better. Could you tell me more about what you are experiencing? Or feel free to browse our Learn section for articles on this topic.",
  }
}

export default function LunaChat({ isPremium }: { isPremium: boolean }) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 0,
      text: "Hello! I am Luna, your menopause wellness companion. I am here to support you through every stage of this journey. What is on your mind today?",
      sender: "luna",
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const sendMessage = () => {
    if (!input.trim()) return

    const userMsg: Message = { id: Date.now(), text: input, sender: "user" }
    setMessages((prev) => [...prev, userMsg])
    setInput("")
    setIsTyping(true)

    setTimeout(() => {
      const response = getLunaResponse(userMsg.text, isPremium)
      const lunaMsg: Message = {
        id: Date.now() + 1,
        text: response.text,
        sender: "luna",
        isPremiumTeaser: response.isPremiumTeaser,
      }
      setMessages((prev) => [...prev, lunaMsg])
      setIsTyping(false)
    }, 1200)
  }

  return (
    <div className="flex flex-col h-[calc(100vh-180px)] pb-24 animate-fade-in">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto scrollbar-hide space-y-4 px-1">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-3 ${msg.sender === "user" ? "flex-row-reverse" : ""}`}
          >
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                msg.sender === "user"
                  ? "bg-lunara-purple text-white"
                  : "bg-lunara-gold/20 text-lunara-gold"
              }`}
            >
              {msg.sender === "user" ? <User size={16} /> : <Sparkles size={16} />}
            </div>
            <div
              className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                msg.sender === "user"
                  ? "bg-lunara-purple text-white rounded-br-md"
                  : msg.isPremiumTeaser
                  ? "bg-lunara-gold/10 border border-lunara-gold/30 text-lunara-dark rounded-bl-md"
                  : "bg-white shadow-sm rounded-bl-md"
              }`}
            >
              {msg.isPremiumTeaser && (
                <div className="flex items-center gap-1 mb-1 text-lunara-gold">
                  <Lock size={12} />
                  <span className="text-xs font-semibold">Premium Insight</span>
                </div>
              )}
              {msg.text}
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-lunara-gold/20 text-lunara-gold flex items-center justify-center shrink-0">
              <Sparkles size={16} />
            </div>
            <div className="bg-white shadow-sm rounded-2xl rounded-bl-md px-4 py-3">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-lunara-purple/40 rounded-full animate-pulse-soft" />
                <div className="w-2 h-2 bg-lunara-purple/40 rounded-full animate-pulse-soft" style={{ animationDelay: "0.2s" }} />
                <div className="w-2 h-2 bg-lunara-purple/40 rounded-full animate-pulse-soft" style={{ animationDelay: "0.4s" }} />
              </div>
            </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Input */}
      <div className="mt-4 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          placeholder="Ask Luna anything..."
          className="flex-1 bg-white rounded-full px-5 py-3 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-lunara-purple/30"
        />
        <button
          onClick={sendMessage}
          disabled={!input.trim() || isTyping}
          className="bg-lunara-purple text-white p-3 rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all disabled:opacity-50 disabled:hover:scale-100"
        >
          <Send size={18} />
        </button>
      </div>

      {!isPremium && (
        <p className="text-xs text-center text-gray-400 mt-2">
          Luna offers general guidance. Premium unlocks personalized plans and detailed protocols.
        </p>
      )}
    </div>
  )
}
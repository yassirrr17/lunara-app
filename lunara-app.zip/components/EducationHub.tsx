"use client"

import { useState } from "react"
import { BookOpen, Lock, Clock, ChevronRight, X, Star } from "lucide-react"

interface Article {
  id: number
  title: string
  category: string
  readTime: string
  isPremium: boolean
  excerpt: string
  content: string
}

const ARTICLES: Article[] = [
  {
    id: 1,
    title: "Understanding Perimenopause: The First Signs",
    category: "Basics",
    readTime: "5 min",
    isPremium: false,
    excerpt: "Learn to recognize the early signals your body sends as you enter perimenopause.",
    content: "Perimenopause typically begins in your 40s, though it can start earlier. The first signs often include changes in your menstrual cycle, mood fluctuations, and sleep disturbances. Your ovaries gradually produce less estrogen, and this transition can last anywhere from a few months to several years. Understanding these changes helps you respond with compassion for your body rather than frustration. Common early symptoms include irregular periods, breast tenderness, worsening premenstrual syndrome, and subtle mood shifts that might feel unfamiliar.",
  },
  {
    id: 2,
    title: "Natural Ways to Manage Hot Flashes",
    category: "Symptoms",
    readTime: "4 min",
    isPremium: false,
    excerpt: "Practical lifestyle changes that can reduce the frequency and intensity of hot flashes.",
    content: "Hot flashes affect up to 80 percent of women during menopause. While they can feel overwhelming, several natural approaches can help. Start by identifying your personal triggers, common ones include spicy foods, caffeine, alcohol, stress, and warm environments. Dressing in breathable layers allows you to adjust quickly. Deep, slow breathing at the onset of a hot flash can reduce its severity. Regular exercise, particularly yoga and swimming, helps regulate body temperature. Some women find relief through acupuncture or herbal supplements like black cohosh, though you should always consult your healthcare provider before starting supplements.",
  },
  {
    id: 3,
    title: "Sleep Better During Menopause",
    category: "Wellness",
    readTime: "6 min",
    isPremium: false,
    excerpt: "Reclaim your rest with proven strategies for menopause-related sleep issues.",
    content: "Sleep disturbances are one of the most disruptive aspects of menopause. Night sweats can wake you repeatedly, while hormonal fluctuations affect your sleep architecture. Create a sleep sanctuary by keeping your bedroom between 16 and 19 degrees Celsius. Invest in moisture-wicking bedding and sleepwear. Establish a consistent wind-down routine starting an hour before bed, dim the lights, avoid screens, and consider a warm bath with magnesium salts. If you wake during the night, resist checking your phone. Instead, try a body scan meditation or progressive muscle relaxation. Limiting fluid intake in the evening reduces nighttime bathroom trips.",
  },
  {
    id: 4,
    title: "The Complete Guide to HRT",
    category: "Treatment",
    readTime: "12 min",
    isPremium: true,
    excerpt: "Everything you need to know about hormone replacement therapy, from types to risks.",
    content: "Hormone Replacement Therapy remains one of the most effective treatments for menopausal symptoms, yet it remains misunderstood. This comprehensive guide covers the different forms of HRT including estrogen-only, combined estrogen-progesterone, and bioidentical options. We explore the latest research on safety profiles, who benefits most, and how to discuss options with your doctor. You'll learn about transdermal patches versus oral tablets, the role of testosterone in women's health, and how to personalize your approach based on your symptoms, health history, and preferences. The guide also addresses common concerns about breast cancer risk and cardiovascular health with current evidence-based context.",
  },
  {
    id: 5,
    title: "Nutritionist-Designed Meal Plans for Hormone Balance",
    category: "Nutrition",
    readTime: "15 min",
    isPremium: true,
    excerpt: "Four weeks of hormone-balancing recipes with shopping lists and prep guides.",
    content: "What you eat directly influences how you feel during menopause. This premium meal plan collection includes four complete weeks of breakfast, lunch, dinner, and snack ideas designed by a registered nutritionist specializing in women's hormonal health. Each plan emphasizes phytoestrogen-rich foods, anti-inflammatory ingredients, and bone-supporting nutrients. You'll receive detailed shopping lists organized by supermarket section, meal prep strategies to save time, and substitution guides for dietary restrictions. Recipes include hormone-balancing smoothie bowls, omega-3 rich salmon dishes, calcium-packed leafy green meals, and satisfying snacks that stabilize blood sugar. The plans are designed for the New Zealand and Australian palate with locally available ingredients.",
  },
  {
    id: 6,
    title: "Strength Training for Menopausal Women",
    category: "Fitness",
    readTime: "10 min",
    isPremium: true,
    excerpt: "A progressive workout program designed specifically for changing bodies.",
    content: "As estrogen declines, maintaining muscle mass becomes crucial for metabolism, bone density, and overall vitality. This progressive strength program is designed specifically for women navigating menopause. It includes three levels, beginner, intermediate, and advanced, with video demonstrations for each exercise. The program focuses on compound movements that build functional strength, core stability work to protect your back and joints, and mobility flows to maintain flexibility. You'll learn proper form for squats, deadlifts, presses, and rows adapted for menopausal bodies. The guide includes a weekly schedule, rest day recommendations, and how to adjust intensity based on your energy levels, which can fluctuate during this phase.",
  },
  {
    id: 7,
    title: "Mental Health and Menopause",
    category: "Mental Health",
    readTime: "7 min",
    isPremium: false,
    excerpt: "Understanding the emotional journey and when to seek professional support.",
    content: "The emotional impact of menopause is real and often underestimated. Hormonal changes can trigger anxiety, low mood, irritability, and even feelings of grief as fertility ends. These feelings are valid. It is important to distinguish between normal menopausal mood fluctuations and clinical depression. If low moods persist for more than two weeks, affect your daily functioning, or include thoughts of self-harm, please seek professional help immediately. For many women, talking therapy provides significant relief. Cognitive Behavioral Therapy has strong evidence for managing menopausal mood symptoms. Building a support network of women going through the same experience can be incredibly validating. Remember, you do not have to navigate this alone.",
  },
  {
    id: 8,
    title: "Bone Health: Prevention and Protection",
    category: "Health",
    readTime: "8 min",
    isPremium: false,
    excerpt: "Protect your bones for life with these evidence-based strategies.",
    content: "Osteoporosis risk increases significantly after menopause due to declining estrogen, which plays a protective role in bone density. The good news is that bone loss is not inevitable. Weight-bearing exercises like walking, dancing, and resistance training stimulate bone formation. Ensure adequate calcium intake through dairy, fortified plant milks, leafy greens, and tinned fish with bones. Vitamin D is essential for calcium absorption, and many women are deficient, especially in winter. In New Zealand and Australia, safe sun exposure guidelines vary by season and latitude, so consider testing your levels. Avoid smoking and excessive alcohol, both of which accelerate bone loss. A DEXA scan can establish your baseline bone density and guide prevention strategies.",
  },
  {
    id: 9,
    title: "Your Personalized Health Report Explained",
    category: "Premium",
    readTime: "20 min",
    isPremium: true,
    excerpt: "How to read and act on your weekly Lunara health report.",
    content: "Your weekly health report is more than a summary, it is a personalized wellness compass. This guide walks you through each section of your report, from symptom pattern analysis to trend predictions. Learn how to identify cyclical patterns in your symptoms, understand correlation insights between lifestyle factors and symptom severity, and use the data to have more informed conversations with your healthcare provider. The report tracks your progress over time, highlighting improvements and flagging areas that may need attention. Premium members receive detailed recommendations based on their unique symptom profile, including suggested lifestyle adjustments, supplement considerations, and discussion points for medical appointments. This guide ensures you get maximum value from every report.",
  },
  {
    id: 10,
    title: "Intimacy and Relationships During Menopause",
    category: "Relationships",
    readTime: "9 min",
    isPremium: true,
    excerpt: "Navigating changing intimacy with confidence and open communication.",
    content: "Physical intimacy often changes during menopause, but it does not have to diminish. Vaginal dryness, reduced libido, and body confidence shifts are common, yet rarely discussed openly. This guide offers practical solutions from lubricants and moisturizers to pelvic floor exercises that enhance sensation. We explore the emotional aspects too, how to communicate desires and concerns with your partner, rebuilding intimacy beyond just the physical, and addressing the grief some women feel as their reproductive chapter closes. The guide includes conversation starters, professional resources for couples therapy, and perspectives from women who have navigated this transition successfully. Your worth and desirability do not end with menopause, they evolve.",
  },
]

const CATEGORIES = ["All", "Basics", "Symptoms", "Wellness", "Nutrition", "Fitness", "Mental Health", "Health", "Treatment", "Relationships"]

export default function EducationHub({ isPremium, onNavigate }: { isPremium: boolean; onNavigate: (screen: string) => void }) {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null)

  const filtered = selectedCategory === "All"
    ? ARTICLES
    : ARTICLES.filter((a) => a.category === selectedCategory)

  return (
    <div className="space-y-6 pb-24 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold">Learn</h1>
        <p className="text-gray-500 text-sm mt-1">Evidence-based guides for your wellness journey</p>
      </div>

      {/* Categories */}
      <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
              selectedCategory === cat
                ? "bg-lunara-purple text-white"
                : "bg-white text-gray-600 hover:bg-lunara-light"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Articles Grid */}
      <div className="grid gap-4">
        {filtered.map((article) => (
          <button
            key={article.id}
            onClick={() => setSelectedArticle(article)}
            className="glass-card rounded-2xl p-5 text-left shadow-sm hover:shadow-md transition-all text-left w-full"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-medium text-lunara-purple bg-lunara-purple/10 px-2 py-0.5 rounded-full">
                    {article.category}
                  </span>
                  {article.isPremium && (
                    <span className="text-xs font-medium text-lunara-gold bg-lunara-gold/10 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Star size={10} />
                      Premium
                    </span>
                  )}
                </div>
                <h3 className="font-semibold text-sm">{article.title}</h3>
                <p className="text-xs text-gray-500 mt-1 line-clamp-2">{article.excerpt}</p>
                <div className="flex items-center gap-3 mt-3 text-xs text-gray-400">
                  <span className="flex items-center gap-1">
                    <Clock size={12} />
                    {article.readTime}
                  </span>
                </div>
              </div>
              <div className="shrink-0 mt-1">
                {article.isPremium && !isPremium ? (
                  <Lock size={18} className="text-lunara-gold" />
                ) : (
                  <ChevronRight size={18} className="text-gray-300" />
                )}
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Article Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-lg max-h-[85vh] overflow-y-auto animate-fade-in shadow-2xl">
            {selectedArticle.isPremium && !isPremium ? (
              <div className="p-8 text-center">
                <button
                  onClick={() => setSelectedArticle(null)}
                  className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
                >
                  <X size={20} />
                </button>
                <div className="w-16 h-16 bg-lunara-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Lock size={28} className="text-lunara-gold" />
                </div>
                <h3 className="font-bold text-lg mb-2">Premium Article</h3>
                <p className="text-gray-500 text-sm mb-6">
                  {selectedArticle.title} is available exclusively for Premium members.
                </p>
                <div className="bg-lunara-light rounded-xl p-4 mb-6 text-left">
                  <p className="text-sm font-medium mb-1">What you will learn:</p>
                  <p className="text-xs text-gray-500">{selectedArticle.excerpt}</p>
                </div>
                <button
                  onClick={() => {
                    setSelectedArticle(null)
                    onNavigate("premium")
                  }}
                  className="w-full py-3 rounded-xl bg-lunara-purple text-white font-medium hover:bg-lunara-purple/90 transition-all"
                >
                  Unlock Premium
                </button>
                <button
                  onClick={() => setSelectedArticle(null)}
                  className="w-full py-3 mt-2 text-sm text-gray-500 hover:text-gray-700 transition-all"
                >
                  Maybe later
                </button>
              </div>
            ) : (
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-medium text-lunara-purple bg-lunara-purple/10 px-2 py-0.5 rounded-full">
                    {selectedArticle.category}
                  </span>
                  <button onClick={() => setSelectedArticle(null)} className="text-gray-400 hover:text-gray-600">
                    <X size={20} />
                  </button>
                </div>
                <h2 className="text-xl font-bold mb-2">{selectedArticle.title}</h2>
                <div className="flex items-center gap-3 text-xs text-gray-400 mb-6">
                  <span className="flex items-center gap-1">
                    <Clock size={12} />
                    {selectedArticle.readTime} read
                  </span>
                  {selectedArticle.isPremium && (
                    <span className="flex items-center gap-1 text-lunara-gold">
                      <Star size={12} />
                      Premium
                    </span>
                  )}
                </div>
                <div className="prose prose-sm max-w-none">
                  <p className="text-sm leading-relaxed text-gray-700">{selectedArticle.content}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
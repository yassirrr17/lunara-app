"use client"

import { useState } from "react"
import { Heart, MessageCircle, Send, User } from "lucide-react"

interface Post {
  id: number
  author: string
  avatar: string
  time: string
  content: string
  likes: number
  comments: number
  liked: boolean
  tag: string
}

const INITIAL_POSTS: Post[] = [
  {
    id: 1,
    author: "Sarah M.",
    avatar: "SM",
    time: "2 hours ago",
    content: "Just had my first hot flash at work today. Was so embarrassed but my colleague was so understanding. Does anyone have tips for managing them in professional settings?",
    likes: 24,
    comments: 8,
    liked: false,
    tag: "Hot Flashes",
  },
  {
    id: 2,
    author: "Jenny K.",
    avatar: "JK",
    time: "5 hours ago",
    content: "Started strength training three months ago and my joint pain has improved so much. If you are on the fence about exercise, just start small. I began with 10 minute walks.",
    likes: 56,
    comments: 12,
    liked: false,
    tag: "Fitness",
  },
  {
    id: 3,
    author: "Anonymous",
    avatar: "AN",
    time: "1 day ago",
    content: "Feeling really low today. The mood swings are hitting hard and I feel like I do not recognize myself. Just needed to say it out loud to people who understand.",
    likes: 89,
    comments: 34,
    liked: false,
    tag: "Mental Health",
  },
  {
    id: 4,
    author: "Maria T.",
    avatar: "MT",
    time: "1 day ago",
    content: "Has anyone tried magnesium for sleep? My naturopath suggested it and I have been sleeping through the night for the first time in months. Game changer!",
    likes: 42,
    comments: 15,
    liked: false,
    tag: "Sleep",
  },
  {
    id: 5,
    author: "Lisa P.",
    avatar: "LP",
    time: "2 days ago",
    content: "Finally talked to my doctor about HRT after reading so much conflicting information online. Feeling relieved to have a plan that feels right for my body.",
    likes: 67,
    comments: 21,
    liked: false,
    tag: "Treatment",
  },
]

const TAGS = ["All", "Hot Flashes", "Sleep", "Fitness", "Mental Health", "Treatment", "Nutrition"]

export default function Community() {
  const [posts, setPosts] = useState(INITIAL_POSTS)
  const [selectedTag, setSelectedTag] = useState("All")
  const [newPost, setNewPost] = useState("")
  const [showNewPost, setShowNewPost] = useState(false)

  const filtered = selectedTag === "All" ? posts : posts.filter((p) => p.tag === selectedTag)

  const toggleLike = (id: number) => {
    setPosts((prev) =>
      prev.map((p) =>
        p.id === id ? { ...p, liked: !p.liked, likes: p.liked ? p.likes - 1 : p.likes + 1 } : p
      )
    )
  }

  const submitPost = () => {
    if (!newPost.trim()) return
    const post: Post = {
      id: Date.now(),
      author: "You",
      avatar: "YO",
      time: "Just now",
      content: newPost,
      likes: 0,
      comments: 0,
      liked: false,
      tag: "General",
    }
    setPosts([post, ...posts])
    setNewPost("")
    setShowNewPost(false)
  }

  return (
    <div className="space-y-6 pb-24 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Community</h1>
          <p className="text-gray-500 text-sm mt-1">Connect with women on the same journey</p>
        </div>
        <button
          onClick={() => setShowNewPost(true)}
          className="bg-lunara-purple text-white p-3 rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all"
        >
          <Send size={18} />
        </button>
      </div>

      {/* Tags */}
      <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
        {TAGS.map((tag) => (
          <button
            key={tag}
            onClick={() => setSelectedTag(tag)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
              selectedTag === tag
                ? "bg-lunara-purple text-white"
                : "bg-white text-gray-600 hover:bg-lunara-light"
            }`}
          >
            {tag}
          </button>
        ))}
      </div>

      {/* Posts */}
      <div className="space-y-4">
        {filtered.map((post) => (
          <div key={post.id} className="glass-card rounded-2xl p-5 shadow-sm">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-lunara-purple/10 text-lunara-purple flex items-center justify-center font-semibold text-sm">
                {post.avatar}
              </div>
              <div className="flex-1">
                <p className="font-semibold text-sm">{post.author}</p>
                <p className="text-xs text-gray-400">{post.time}</p>
              </div>
              <span className="text-xs bg-lunara-light text-lunara-purple px-2 py-0.5 rounded-full">
                {post.tag}
              </span>
            </div>
            <p className="text-sm text-gray-700 leading-relaxed mb-4">{post.content}</p>
            <div className="flex items-center gap-6">
              <button
                onClick={() => toggleLike(post.id)}
                className={`flex items-center gap-1.5 text-sm transition-all ${
                  post.liked ? "text-red-500" : "text-gray-400 hover:text-red-400"
                }`}
              >
                <Heart size={16} fill={post.liked ? "currentColor" : "none"} />
                {post.likes}
              </button>
              <button className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-lunara-purple transition-all">
                <MessageCircle size={16} />
                {post.comments}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* New Post Modal */}
      {showNewPost && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 animate-fade-in shadow-2xl">
            <h3 className="font-bold text-lg mb-4">Share with the community</h3>
            <textarea
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              placeholder="What is on your mind? This is a safe space..."
              className="w-full bg-lunara-light rounded-xl p-4 text-sm resize-none h-32 focus:outline-none focus:ring-2 focus:ring-lunara-purple/30"
            />
            <div className="flex gap-3 mt-4">
              <button
                onClick={() => setShowNewPost(false)}
                className="flex-1 py-3 rounded-xl border border-gray-200 text-sm font-medium hover:bg-gray-50 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={submitPost}
                className="flex-1 py-3 rounded-xl bg-lunara-purple text-white text-sm font-medium hover:bg-lunara-purple/90 transition-all"
              >
                Post
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
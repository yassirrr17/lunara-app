# Lunara - Menopause Wellness App

A beautiful, fully functional frontend prototype of the Lunara menopause wellness app. Built with Next.js, React, TypeScript, and Tailwind CSS.

## Features

- **Dashboard** - Personalized welcome screen with today's symptom snapshot, quick actions, and daily tips
- **Symptom Tracker** - Log and track 12 common menopause symptoms with severity ratings and notes. View weekly trends.
- **Luna AI Chat** - AI wellness companion with premium-aware responses. Free users get helpful general guidance. Premium topics trigger gentle upsell messages.
- **Education Hub** - Evidence-based articles organized by category. Some articles free, premium articles locked with unlock prompts.
- **Community** - Forum-style community with posts, likes, comments, and tagging. Create your own posts.
- **Premium Subscription** - Monthly ($10) and Yearly ($60) plans. Demo mode toggle for testing.
- **Onboarding** - User name and age collection on first launch
- **Local Storage** - All data persists in the browser (symptoms, user profile, posts)

## Tech Stack

- Next.js 14 (App Router)
- React 18
- TypeScript
- Tailwind CSS
- Lucide React (icons)

## Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Run locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### 3. Build for production

```bash
npm run build
```

This creates a static export in the `dist` folder.

## Deploy on Vercel

### Option 1: GitHub + Vercel (Recommended)

1. Create a new repository on GitHub
2. Push this code to the repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/lunara-app.git
   git push -u origin main
   ```
3. Go to [vercel.com](https://vercel.com) and sign up/login
4. Click "Add New Project"
5. Import your GitHub repository
6. Vercel will auto-detect Next.js and deploy it
7. Your app will be live at `https://lunara-app.vercel.app` (or similar)

### Option 2: Vercel CLI

```bash
npm i -g vercel
vercel
```

Follow the prompts to deploy.

## Customizing

### Colors
Edit `tailwind.config.js` to change the color scheme:
```js
colors: {
  lunara: {
    purple: '#8B6F9B',
    pink: '#D4A5A5',
    cream: '#FDF8F5',
    gold: '#E8B86D',
    dark: '#3D3D3D',
    light: '#F5F0ED',
    rose: '#C9A9A6',
  }
}
```

### Content
- **Articles**: Edit `components/EducationHub.tsx`
- **AI Responses**: Edit `components/LunaChat.tsx`
- **Community Posts**: Edit `components/Community.tsx`
- **Symptoms**: Edit `components/SymptomTracker.tsx`

### Adding Real Backend
This is a frontend prototype. To make it production-ready, you would need:
- Authentication (Clerk, Auth0, or NextAuth)
- Database (Supabase, MongoDB, or PostgreSQL)
- Real AI (OpenAI API or similar)
- Payments (Stripe)
- Hosting with serverless functions

## File Structure

```
lunara-app/
├── app/
│   ├── layout.tsx      # Root layout with metadata
│   ├── page.tsx        # Main app with navigation and all screens
│   └── globals.css     # Global styles and Tailwind imports
├── components/
│   ├── Dashboard.tsx       # Home dashboard
│   ├── SymptomTracker.tsx  # Symptom logging and trends
│   ├── LunaChat.tsx        # AI chat interface
│   ├── EducationHub.tsx    # Articles and premium content
│   └── Community.tsx       # Community forum
├── package.json
├── next.config.js
├── tailwind.config.js
├── tsconfig.json
└── postcss.config.js
```

## Notes

- This app uses browser localStorage for data persistence. Clearing browser data will reset everything.
- The premium toggle in the Premium screen is for demo purposes. In a real app, this would connect to Stripe.
- Luna AI uses rule-based responses. In production, replace with OpenAI API or similar.
- The app is designed mobile-first but works on desktop too.

## License

MIT - Do whatever you want with it.
